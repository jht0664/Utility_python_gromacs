#!/bin/bash
export OMP_STACKSIZE=200M
./main_structure Na73-65wtPr_rename.gro traj > Sq_full_avg
